package com.titanglide.diagnostic;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.inputmethodservice.InputMethodService;
import android.os.SystemClock;
import android.view.InputDevice;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class TitanGlideIme extends InputMethodService {
    private SharedPreferences prefs;
    private TextView diagnosticBar;
    private int activeKeyCode = KeyEvent.KEYCODE_UNKNOWN;
    private long activeKeyDownMs = 0L;
    private long lastMoveLogMs = 0L;
    private final SimpleDateFormat clock = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    @Override
    public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        log("IME service created");
    }

    @Override
    public View onCreateInputView() {
        if (!prefs.getBoolean(MainActivity.PREF_SHOW_BAR, true)) {
            return new View(this);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(6), dp(10), dp(6));
        root.setBackgroundColor(Color.rgb(24, 24, 24));

        TextView name = new TextView(this);
        name.setText("Titan Glide diagnostic");
        name.setTextColor(Color.WHITE);
        name.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        name.setTextSize(13);
        root.addView(name);

        diagnosticBar = new TextView(this);
        diagnosticBar.setText("Waiting for key/motion events…");
        diagnosticBar.setTextColor(Color.rgb(215, 215, 215));
        diagnosticBar.setTypeface(Typeface.MONOSPACE);
        diagnosticBar.setTextSize(10);
        diagnosticBar.setMaxLines(3);
        root.addView(diagnosticBar);
        return root;
    }

    @Override
    public boolean onEvaluateInputViewShown() {
        return prefs == null || prefs.getBoolean(MainActivity.PREF_SHOW_BAR, true);
    }

    @Override
    public void onStartInputView(android.view.inputmethod.EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        log("Input view started: package=" + (info == null ? "?" : info.packageName));
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event != null && event.getRepeatCount() == 0) {
            activeKeyCode = keyCode;
            activeKeyDownMs = SystemClock.uptimeMillis();
        }
        String line = "KEY DOWN " + keyName(keyCode, event) + eventDetails(event);
        log(line);
        show(line);

        // Diagnostic build: never consume normal physical typing.
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        long heldMs = (keyCode == activeKeyCode && activeKeyDownMs > 0)
                ? SystemClock.uptimeMillis() - activeKeyDownMs : -1L;
        int threshold = prefs.getInt(MainActivity.PREF_HOLD_MS, 425);
        String classification = heldMs >= threshold ? " LONG_HOLD" : "";
        String line = "KEY UP   " + keyName(keyCode, event) +
                (heldMs >= 0 ? " held=" + heldMs + "ms" : "") + classification + eventDetails(event);
        log(line);
        show(line);
        if (keyCode == activeKeyCode) {
            activeKeyCode = KeyEvent.KEYCODE_UNKNOWN;
            activeKeyDownMs = 0L;
        }

        // Diagnostic build: never consume normal physical typing.
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public boolean onKeyMultiple(int keyCode, int count, KeyEvent event) {
        String line = "KEY MULTIPLE " + keyName(keyCode, event) + " count=" + count + eventDetails(event);
        log(line);
        show(line);
        return super.onKeyMultiple(keyCode, count, event);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {
        if (!prefs.getBoolean(MainActivity.PREF_LOG_MOTION, true)) {
            return super.onGenericMotionEvent(event);
        }
        if (event == null) return super.onGenericMotionEvent(null);

        int action = event.getActionMasked();
        long now = SystemClock.uptimeMillis();
        boolean highRate = action == MotionEvent.ACTION_MOVE || action == MotionEvent.ACTION_HOVER_MOVE;
        if (!highRate || now - lastMoveLogMs >= 25L) {
            lastMoveLogMs = now;
            String line = motionLine("GENERIC", event);
            log(line);
            show(line);
        }

        // Important: observe only. Let the foreground app/SystemUI keep processing the motion.
        return super.onGenericMotionEvent(event);
    }

    @Override
    public boolean onTrackballEvent(MotionEvent event) {
        if (prefs.getBoolean(MainActivity.PREF_LOG_MOTION, true) && event != null) {
            String line = motionLine("TRACKBALL", event);
            log(line);
            show(line);
        }
        return super.onTrackballEvent(event);
    }

    private String motionLine(String kind, MotionEvent e) {
        StringBuilder b = new StringBuilder();
        b.append(kind)
                .append(" ").append(MotionEvent.actionToString(e.getAction()))
                .append(" src=0x").append(Integer.toHexString(e.getSource()))
                .append(" dev=").append(e.getDeviceId())
                .append(" x=").append(fmt(e.getX()))
                .append(" y=").append(fmt(e.getY()))
                .append(" raw=").append(fmt(e.getRawX())).append(',').append(fmt(e.getRawY()));

        InputDevice d = e.getDevice();
        if (d != null) {
            b.append(" device=\"").append(d.getName()).append("\"");
            List<InputDevice.MotionRange> ranges = d.getMotionRanges();
            if (ranges != null && !ranges.isEmpty()) {
                b.append(" axes[");
                boolean first = true;
                for (InputDevice.MotionRange r : ranges) {
                    float v;
                    try {
                        v = e.getAxisValue(r.getAxis());
                    } catch (RuntimeException ex) {
                        continue;
                    }
                    if (Math.abs(v) > 0.0001f || r.getAxis() == MotionEvent.AXIS_X || r.getAxis() == MotionEvent.AXIS_Y) {
                        if (!first) b.append(' ');
                        first = false;
                        b.append(MotionEvent.axisToString(r.getAxis())).append('=').append(fmt(v));
                    }
                }
                b.append(']');
            }
        }
        return b.toString();
    }

    private String eventDetails(KeyEvent e) {
        if (e == null) return "";
        InputDevice d = e.getDevice();
        return " repeat=" + e.getRepeatCount() +
                " scan=" + e.getScanCode() +
                " meta=0x" + Integer.toHexString(e.getMetaState()) +
                " dev=" + e.getDeviceId() +
                (d == null ? "" : " device=\"" + d.getName() + "\"");
    }

    private String keyName(int keyCode, KeyEvent e) {
        StringBuilder b = new StringBuilder(KeyEvent.keyCodeToString(keyCode));
        if (e != null) {
            int unicode = e.getUnicodeChar();
            if (unicode > 0 && !Character.isISOControl(unicode)) {
                b.append(" '").append((char) unicode).append("'");
            }
        }
        return b.toString();
    }

    private void log(String message) {
        if (prefs == null) return;
        String time = clock.format(new Date());
        String old = prefs.getString(MainActivity.PREF_LOG, "");
        String next = time + "  " + message + "\n" + old;
        if (next.length() > 50000) next = next.substring(0, 50000);
        prefs.edit().putString(MainActivity.PREF_LOG, next).apply();
    }

    private void show(String message) {
        if (diagnosticBar != null) diagnosticBar.setText(message);
    }

    private String fmt(float value) {
        return String.format(Locale.US, "%.3f", value);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
