package com.titanglide.diagnostic;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.InputDevice;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    public static final String PREFS = "titan_glide_prefs";
    public static final String PREF_HOLD_MS = "hold_ms";
    public static final String PREF_LOG_MOTION = "log_motion";
    public static final String PREF_SHOW_BAR = "show_bar";
    public static final String PREF_LOG = "event_log";

    private SharedPreferences prefs;
    private TextView statusView;
    private TextView holdValueView;
    private TextView logView;
    private TextView devicesView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        scroll.addView(root);

        TextView title = text("Titan Glide 0.1", 26, true);
        root.addView(title);

        TextView subtitle = text(
                "Hardware diagnostic for the Titan physical keyboard. This build does not perform word-glide typing yet. Its job is to prove which key and capacitive motion events Android exposes to an IME.",
                15, false);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        statusView = text("", 15, true);
        statusView.setPadding(dp(12), dp(10), dp(12), dp(10));
        statusView.setBackgroundColor(Color.rgb(238, 238, 238));
        root.addView(statusView, matchWrap());

        Button enable = button("1. Enable Titan Glide in keyboard settings");
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        root.addView(enable, matchWrap());

        Button picker = button("2. Choose Titan Glide as current keyboard");
        picker.setOnClickListener(v -> {
            InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showInputMethodPicker();
        });
        root.addView(picker, matchWrap());

        section(root, "Long-press timing");
        holdValueView = text("", 15, true);
        root.addView(holdValueView);

        SeekBar holdSeek = new SeekBar(this);
        holdSeek.setMax(850); // 150..1000 ms
        int holdMs = clamp(prefs.getInt(PREF_HOLD_MS, 425), 150, 1000);
        holdSeek.setProgress(holdMs - 150);
        updateHoldLabel(holdMs);
        holdSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int ms = progress + 150;
                prefs.edit().putInt(PREF_HOLD_MS, ms).apply();
                updateHoldLabel(ms);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        root.addView(holdSeek, matchWrap());

        TextView holdHelp = text(
                "For this diagnostic build, the delay controls when a physical press is logged as a LONG HOLD. In the real keyboard it will be the symbol threshold.",
                13, false);
        root.addView(holdHelp);

        Switch motionSwitch = new Switch(this);
        motionSwitch.setText("Capture generic/trackball motion events");
        motionSwitch.setTextSize(15);
        motionSwitch.setChecked(prefs.getBoolean(PREF_LOG_MOTION, true));
        motionSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs.edit().putBoolean(PREF_LOG_MOTION, isChecked).apply());
        root.addView(motionSwitch, matchWrap());

        Switch barSwitch = new Switch(this);
        barSwitch.setText("Show small diagnostic bar while keyboard is active");
        barSwitch.setTextSize(15);
        barSwitch.setChecked(prefs.getBoolean(PREF_SHOW_BAR, true));
        barSwitch.setOnCheckedChangeListener((buttonView, isChecked) ->
                prefs.edit().putBoolean(PREF_SHOW_BAR, isChecked).apply());
        root.addView(barSwitch, matchWrap());

        section(root, "Exact test");
        TextView steps = text(
                "A. Open a text box with Titan Glide selected.\n" +
                "B. Press H once and release it.\n" +
                "C. Keep your thumb touching the physical keyboard surface.\n" +
                "D. Glide toward E, then L, then O without pressing those keys.\n" +
                "E. Lift your thumb.\n\n" +
                "We want to see motion events after KEY_H UP. Normal typing is intentionally passed through unchanged in this build.",
                14, false);
        root.addView(steps);

        EditText testField = new EditText(this);
        testField.setHint("Test typing here");
        testField.setTextSize(18);
        testField.setMinHeight(dp(72));
        testField.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(testField, matchWrap());

        section(root, "Captured IME events");
        LinearLayout logButtons = horizontal();
        Button refreshLog = button("Refresh");
        refreshLog.setOnClickListener(v -> refreshLog());
        Button clearLog = button("Clear");
        clearLog.setOnClickListener(v -> {
            prefs.edit().remove(PREF_LOG).apply();
            refreshLog();
        });
        Button copyLog = button("Copy log");
        copyLog.setOnClickListener(v -> copyText("Titan Glide event log", prefs.getString(PREF_LOG, "")));
        logButtons.addView(refreshLog, weighted());
        logButtons.addView(clearLog, weighted());
        logButtons.addView(copyLog, weighted());
        root.addView(logButtons, matchWrap());

        logView = text("", 11, false);
        logView.setTypeface(Typeface.MONOSPACE);
        logView.setTextIsSelectable(true);
        logView.setPadding(dp(8), dp(8), dp(8), dp(8));
        logView.setBackgroundColor(Color.rgb(245, 245, 245));
        root.addView(logView, matchWrap());

        section(root, "Android input devices");
        LinearLayout deviceButtons = horizontal();
        Button refreshDevices = button("Refresh devices");
        refreshDevices.setOnClickListener(v -> refreshDevices());
        Button copyDevices = button("Copy report");
        copyDevices.setOnClickListener(v -> copyText("Titan Glide device report", devicesView.getText().toString()));
        deviceButtons.addView(refreshDevices, weighted());
        deviceButtons.addView(copyDevices, weighted());
        root.addView(deviceButtons, matchWrap());

        devicesView = text("", 11, false);
        devicesView.setTypeface(Typeface.MONOSPACE);
        devicesView.setTextIsSelectable(true);
        devicesView.setPadding(dp(8), dp(8), dp(8), dp(8));
        devicesView.setBackgroundColor(Color.rgb(245, 245, 245));
        root.addView(devicesView, matchWrap());

        setContentView(scroll);
        refreshAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (prefs != null) refreshAll();
    }

    private void refreshAll() {
        refreshStatus();
        refreshLog();
        refreshDevices();
    }

    private void refreshStatus() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_INPUT_METHODS);
        String current = Settings.Secure.getString(getContentResolver(), Settings.Secure.DEFAULT_INPUT_METHOD);
        boolean isEnabled = enabled != null && enabled.contains(getPackageName());
        boolean isCurrent = current != null && current.startsWith(getPackageName() + "/");
        String s = "IME enabled: " + (isEnabled ? "YES" : "NO") +
                "\nCurrently selected: " + (isCurrent ? "YES" : "NO");
        statusView.setText(s);
    }

    private void refreshLog() {
        String log = prefs.getString(PREF_LOG, "");
        logView.setText(log.isEmpty() ? "No events captured yet." : log);
    }

    private void refreshDevices() {
        StringBuilder out = new StringBuilder();
        int[] ids = InputDevice.getDeviceIds();
        for (int id : ids) {
            InputDevice d = InputDevice.getDevice(id);
            if (d == null) continue;
            out.append("ID ").append(id)
                    .append("  ").append(d.getName()).append('\n')
                    .append("  descriptor: ").append(d.getDescriptor()).append('\n')
                    .append("  vendor/product: ").append(d.getVendorId()).append('/').append(d.getProductId()).append('\n')
                    .append("  sources: 0x").append(Integer.toHexString(d.getSources())).append('\n');
            for (InputDevice.MotionRange r : d.getMotionRanges()) {
                out.append(String.format(Locale.US,
                        "  axis=%d source=0x%s min=%.3f max=%.3f flat=%.3f fuzz=%.3f res=%.3f%n",
                        r.getAxis(), Integer.toHexString(r.getSource()), r.getMin(), r.getMax(),
                        r.getFlat(), r.getFuzz(), r.getResolution()));
            }
            out.append('\n');
        }
        if (out.length() == 0) out.append("No Android input devices reported.");
        devicesView.setText(out.toString());
    }

    private void copyText(String label, String value) {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText(label, value == null ? "" : value));
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateHoldLabel(int ms) {
        holdValueView.setText("Long-press symbol delay: " + ms + " ms");
    }

    private void section(LinearLayout root, String title) {
        TextView v = text(title, 18, true);
        v.setPadding(0, dp(20), 0, dp(6));
        root.addView(v);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        return l;
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(Color.rgb(30, 30, 30));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(5), 0, dp(5));
        return p;
    }

    private LinearLayout.LayoutParams weighted() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
