# Titan Glide 0.1 — Hardware Diagnostic IME

This is the first diagnostic build for a proposed Unihertz Titan 2 Elite Pro keyboard that works like this:

1. Physically press the first letter of a word.
2. Release that key while keeping the thumb on the capacitive keyboard surface.
3. Glide across the remaining letters without depressing them.
4. Lift the thumb to commit the predicted word.

The eventual keyboard will also support long-press symbols with an adjustable hold duration.

## What 0.1 does

- Registers as a real Android input method (IME).
- Passively logs physical key down/up/multiple events.
- Logs `InputMethodService.onGenericMotionEvent()` events.
- Logs `InputMethodService.onTrackballEvent()` events.
- Records device name, input source, X/Y, raw coordinates, motion axes and scan codes.
- Displays all Android input devices and motion ranges.
- Includes an adjustable 150–1000 ms long-press threshold. In 0.1 it classifies a press as `LONG_HOLD`; in the real keyboard this becomes the symbol delay.
- Does **not** consume normal typing or motion, so the phone should remain usable while testing.

## Exact hardware test

1. Install and open Titan Glide.
2. Tap **Enable Titan Glide in keyboard settings** and enable it.
3. Tap **Choose Titan Glide as current keyboard** and select it.
4. Open the included test field or another text box.
5. Press `H` once and release it.
6. Keep your thumb on the keyboard surface.
7. Glide toward `E`, then `L`, then `O` without depressing those keys.
8. Lift your thumb.
9. Return to Titan Glide, tap **Refresh** under Captured IME events, and copy the log.

The key result is whether motion events appear *after* `KEYCODE_H ... KEY UP`.

## Build

The project intentionally uses only the Android framework, with no third-party runtime dependencies.

- Android Studio: open this folder and build/run the `app` module.
- Command line: Android SDK 35 + JDK 17/21, then run `./gradlew assembleDebug` if a Gradle wrapper has been generated.

A GitHub Actions workflow is included and can build the debug APK automatically when the project is pushed to GitHub.
